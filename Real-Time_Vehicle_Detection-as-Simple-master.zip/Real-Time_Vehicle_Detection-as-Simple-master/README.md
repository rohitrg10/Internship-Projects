# Real-Time Vehicle Detection using Open-CV

The objective of the program given is to detect object of interest(Car) in video frames and to keep tracking the same object. This is an example of how to detect vehicles in Python.

# Why Vehicle Detection?

The startling losses both in human lives and finance caused by vehicle accidents.
Detecting vehicles in images acquired from a moving platform is a challenging problem.
