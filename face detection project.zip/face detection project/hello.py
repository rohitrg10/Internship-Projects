#python basics
#print('hello')
#int g;
g=56
x=5
x=10
y=7
st1="Welcome to "
st2="Machine Learning"
r=6.3443
print(r)
'''
sum=0
st3=st1+st2
print(x)
'''
#print(st3)
if x is 10:
   print('both are true')
   print('Yes both are true')
   

   



    