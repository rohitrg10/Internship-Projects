print('hello')
def add123():
    kernel = 5
    canny = 10
    canny=kernel+canny
    return canny

y= add123()
print(y)
