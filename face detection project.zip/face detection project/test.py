print('welcome')
x="Hello"
y=" World"
z=x+y+"!!!!!!"
if y==" World":
   print(z)
   print(x)