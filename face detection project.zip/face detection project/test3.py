
x=98
y=34
f='Welcome to'
h=' machine learning'
print(x+y)
print(f+h)
while True:
    x=x+1
    print(x)
    print("hello")
    
    