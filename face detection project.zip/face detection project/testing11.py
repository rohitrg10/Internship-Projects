st="hello"
print(st[:3])