tu = (23, "abc", 4.56, (2,3), "def")
li = ['abc', 34, 4.34, 23]
st = 'Hello World'
st = 'hello welcome to mesoln'
print(tu[2])
print(li[1])
print(st[1])
li[3]=3.14
#tu[2]=1.2
print(li[3])

